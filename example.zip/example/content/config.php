<main>

	<header>
		<h3>Config</h3>
	</header>

	<section>
		<p>Below is the configuration used for browsing the JSON structure using the <code>json</code> method.</p>
	</section>

	<pre class="wd-code" style="overflow: auto;"><?php echo $driver->json(); ?></pre>

</main>
