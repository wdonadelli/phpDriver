<main>

	<header>
		<h3>User 2</h3>
	</header>

	<p>This page can only be displayed by <b>user 2</b>, as the function present in the <code>ALLOW</code> key denies access to the other user.</p>

</main>
