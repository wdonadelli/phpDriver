<main>

	<header>
		<h3>User 1</h3>
	</header>

	<section>
		<p>This page can only be displayed by <b>user 1</b>, as the function present in the <code>ALLOW</code> key denies access to the other user.</p>

		<p><a href="?">Click here</a> to continue.</p>

	</section>




</main>
