<main>

	<header>
		<h3>Debug</h3>
	</header>

	<section>
		<p>Below is the data stored in the session using the <code>debug</code> method.</p>
	</section>

	<pre class="wd-code" style="overflow: auto;"><?php print_r($driver->debug()); ?></pre>

</main>
