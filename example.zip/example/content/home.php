<main>

	<header>
		<h3>Home</h3>
	</header>

	<section>
		<p>This main page is defined in the <code>HOME</code> key.</p>
		<p>Maximum time between requests is <time datetime="00:03">3 minutes</time> if access is restricted.</p>
	</section>

</main>
